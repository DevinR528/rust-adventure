{"question":"fn second(_x: &str, y: &str) -> &str {\n    y\n}\n\nfn main() {}\n","ans_loc":"/home/devinr/aprog/rust/rust-adventure/answers/second.rs"}
